<?php
namespace backend\controllers;

use Yii;
use backend\models\SwimServiceAdvisor;
use backend\models\SwimServiceAdvisorSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;

/**
 * SwimServiceAdvisorController implements the CRUD actions for SwimServiceAdvisor model.
 */
class SwimServiceAdvisorController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
           'verbs' => [
               'class' => VerbFilter::className(),
               'actions' => [
                   'delete' => ['POST'],
               ],
           ],
         'access' => [
           'class' => AccessControl::className(),
           'rules' => [
               [
                   'allow' => true,
                   'roles' => ['@'],
               ],

               // ...
           ],
       ],


       ];
    }

    /**
     * Lists all SwimServiceAdvisor models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new SwimServiceAdvisorSearch();
        $dataProvider = $searchModel->search4(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single SwimServiceAdvisor model.
     * @param string $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new SwimServiceAdvisor model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
      public function actionCreate()
    {
        $model = new SwimServiceAdvisor();
		
        if ($model->load(Yii::$app->request->post())) {
        	
				$POST_VARIABLE =Yii::$app->request->post('SwimServiceAdvisor');
               //$request = $POST_VARIABLE['active_status'];
			   //$model->active_status=$request;
            if($model->save())
            {
                Yii::$app->getSession()->setFlash('success','Service Advisor created successfully');
                return $this->redirect(['index']);
            }
            else
            {
            	print_r($model->getErrors());
                 //Yii::$app->getSession()->setFlash('error','Error on creation');
                //return $this->redirect(['index']);
            }
            
        } else {
           /* echo "<pre>";
            print_r($model->getErrors());
            exit();*/
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing SwimServiceAdvisor model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param string $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
        	
				$POST_VARIABLE =Yii::$app->request->post('SwimServiceAdvisor');
               //$request = $POST_VARIABLE['active_status'];
			  // $model->active_status=$request;
			   $model->update();
            return $this->redirect(['view', 'id' => $model->sa_autoid]);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing SwimServiceAdvisor model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param string $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        //$this->findModel($id)->delete();
         $model = $this->findModel($id);
		$model->sa_status ="D";
        $model->update();  

        return $this->redirect(['index']);
    }

    /**
     * Finds the SwimServiceAdvisor model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param string $id
     * @return SwimServiceAdvisor the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = SwimServiceAdvisor::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
