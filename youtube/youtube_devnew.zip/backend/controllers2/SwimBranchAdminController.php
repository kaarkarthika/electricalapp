<?php

namespace backend\controllers;

use Yii;
use backend\models\SwimBranchAdmin;
use backend\models\SwimBranchAdminSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use backend\models\Userdetails;
use backend\models\Frontenduser;
use backend\models\SwimBranchServiceCentre;
use backend\models\SwimBaranch;
use yii\filters\AccessControl;




/**
 * SwimBranchAdminController implements the CRUD actions for SwimBranchAdmin model.
 */
class SwimBranchAdminController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
           'verbs' => [
               'class' => VerbFilter::className(),
               'actions' => [
                   'delete' => ['POST'],
               ],
           ],
         'access' => [
           'class' => AccessControl::className(),
           'rules' => [
               [
                   'allow' => true,
                   'roles' => ['@'],
               ],

               // ...
           ],
       ],


       ];
    }

    /**
     * Lists all SwimBranchAdmin models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new SwimBranchAdminSearch();
        $dataProvider = $searchModel->search1(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single SwimBranchAdmin model.
     * @param string $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->renderAjax('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new SwimBranchAdmin model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new SwimBranchAdmin();
        // $model1 = new Userdetails();
        $model1 = new Frontenduser();

        if ($model->load(Yii::$app->request->post()) ) {
         $branchid=Yii::$app->request->post('SwimBranchAdmin')['ba_branchid'];


            $bacode=Yii::$app->request->post('SwimBranchAdmin')['ba_code'];
             $password=Yii::$app->request->post('SwimBranchAdmin')['password_hash'];
             
                    
                    //$model->save();
                    if($model->save())
                    {
                        //  $model1 = new Frontenduser();
                          
                          //$password="admin";
                $model1->password_hash = Yii::$app->security->generatePasswordHash($password);
                $model1->auth_key = Yii::$app->security->generateRandomString();

                       $model1->branch_id=$branchid;

                        $model1->username=$bacode;
                        $model1->save();
                        Yii::$app->getSession()->setFlash('success','Branch Admin Created successfully');
                    }
                    else
                    {
                       // Yii::$app->getSession()->setFlash('error','Name already exist.');
                         //echo "<pre>";
                         //print_r($model->getErrors());
                         //exit();
                    }

           // return $this->redirect(['view', 'id' => $model->ba_autoid]);
             return $this->redirect(['index']);
        } else {
            return $this->render('create', [
                'model' => $model,
                'model1' => $model1,
            ]);
        }
    }
    public function actionLists($id)
    {
        
        $countposts=SwimBranchServiceCentre::find()
                ->where(['service_center_id'=>$id])
                ->count();
        $posts=SwimBranchServiceCentre::find()
                ->where(['service_center_id'=>$id])
                ->orderBy('scb_id ASC')
                ->all();

        
                    
        if($posts>0)
        {
            foreach($posts as $post)
            {
                $branchid=$post->branch_id;
                $branch=SwimBaranch::find()
                ->where(['branch_autoid'=>$branchid])->one();
                
                

                echo "<option value='".$branch->branch_autoid."'>".$branch->branch_name."</option>";
            }
        }
        else
        {
            echo "<option>--</option>";
        }
    }
    /**
     * Updates an existing SwimBranchAdmin model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param string $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['index']);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing SwimBranchAdmin model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param string $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        // $this->findModel($id)->delete();
        
        // return $this->redirect(['index']);
        $model=$this->findModel($id);
        
        $model->ba_status='D';

        if($model->save())
        {
            Yii::$app->getSession()->setFlash('success','Branch admin deleted successfully');
        } 

        return $this->redirect(['index']);
    }

    // public function actionLists($id)
    // {
        
    //     $countposts=SWimServiceAdvisor::find()
    //             ->where(['sa_branch'=>$id])
    //             ->count();
    //     $posts=SWimServiceAdvisor::find()
    //             ->where(['sa_branch'=>$id])
    //             ->orderBy('sa_autoid DESC')
    //             ->all();
                
    //     if($posts>0)
    //     {
    //         foreach($posts as $post)
    //         {
    //             echo "<option value='".$post->sa_branch."'>".$post->sa_branch."</option>";
    //         }
    //     }
    //     else
    //     {
    //         echo "<option>--</option>";
    //     }
    // }

    /**
     * Finds the SwimBranchAdmin model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param string $id
     * @return SwimBranchAdmin the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = SwimBranchAdmin::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
