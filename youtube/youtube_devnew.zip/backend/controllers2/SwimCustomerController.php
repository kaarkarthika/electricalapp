<?php

namespace backend\controllers;

use Yii;
use backend\models\SwimCustomer;
use backend\models\SwimCustomerSearch;
use backend\models\SwimTokenNumber;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
/**
 * SwimCustomerController implements the CRUD actions for SwimCustomer model.
 */
class SwimCustomerController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
            'access' => [
           'class' => AccessControl::className(),
           'rules' => [
               [
                   'allow' => true,
                   'roles' => ['@'],
               ],

               // ...
           ],
       ],
        ];
    }

    /**
     * Lists all SwimCustomer models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new SwimCustomerSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single SwimCustomer model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->renderAjax('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new SwimCustomer model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new SwimCustomer();
		if(Yii::$app->request->post('SwimCustomer')['customer_branch']){
			$branchid=Yii::$app->request->post('SwimCustomer')['customer_branch'];
			$customer_purpose=Yii::$app->request->post('SwimCustomer')['customer_purpose'];
			$model_token = SwimTokenNumber::find()->where(['token_branch_id'=>$branchid])->andWhere(['token_active'=>'open'])->andWhere(['token_purpose'=>$customer_purpose])->one();
			$todaydate=date('Y-m-d');
			if($model_token){
				// $todaydate='2016-09-07';
				if($model_token->token_date<$todaydate){
					$model_token_update = SwimTokenNumber::find()->where(['token_autoid'=>$model_token->token_autoid])->one();
					$model_token_update->token_active='closed';
					$model_token_update->save();
					$insertnew="yes";//new day	
				}else{
					$token_number=$model_token->token_prefix.$model_token->token_value;
					$model_token_update = SwimTokenNumber::find()->where(['token_autoid'=>$model_token->token_autoid])->one();
					$model_token_update->token_value=$model_token->token_value+1;
					$model_token_update->save();
				}
			}else{
				$insertnew="yes";//new branch!! Not exit
			}
			if($insertnew=="yes"){
				$customer_prefix='';
				if($customer_purpose=='service'){
					$customer_prefix='S';
				}elseif($customer_purpose=='pickup'){
					$customer_prefix='P';
				}
				$start_value=101;
				$create_new_token = new SwimTokenNumber();
				$create_new_token->token_branch_id=$branchid;
				$create_new_token->token_value=$start_value+1;				
				$create_new_token->token_prefix=$customer_prefix;
				$create_new_token->token_purpose=$customer_purpose;
				$create_new_token->token_date=$todaydate;
				$create_new_token->token_active='open';
				$create_new_token->save();
				$token_number=$customer_prefix.$start_value;
			}
		}
        if ($model->load(Yii::$app->request->post())) {
        	$model->customer_token_value=$token_number;
			$model->customer_token_date=$todaydate;
        	if($model->save()){
        		return $this->redirect(['view', 'id' => $model->customer_autoid]);
			}          
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing SwimCustomer model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->customer_autoid]);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing SwimCustomer model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the SwimCustomer model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return SwimCustomer the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = SwimCustomer::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
