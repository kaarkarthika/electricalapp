<?php
return [
    'adminEmail' => 'admin@example.com',
    'pagination' => array('5' => '5', '10' => '10', '20' => '20', '50' => '50', '100' => '100'),
];
