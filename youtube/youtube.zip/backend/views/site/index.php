<?php

/* @var $this yii\web\View */

$this->title = 'Anitha Pushpavanam Kuppusamy - Dashboard';

//Set Default Timezone
date_default_timezone_set('Asia/Kolkata');
?>
<section class="content-header">
          <h1>
            Dashboard
            <small>Control panel</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>
</section>
<div class="site-index">

</div>
